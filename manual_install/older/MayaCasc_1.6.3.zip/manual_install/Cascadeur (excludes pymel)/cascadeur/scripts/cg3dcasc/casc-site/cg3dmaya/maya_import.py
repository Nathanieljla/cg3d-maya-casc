


import json
#import typing
import tempfile
import os
import pathlib
#import uuid

import common.hierarchy as hierarchy
#import rig_gen.add_support_info as rg_s_inf
#import commands.rig_info.add_joints as aj
import csc
import pycsc
import rig_mode.on as rm_on
#import rig_mode.off as rm_off

#from . import server

from . import common
from . import fbx



def _import_maya_qrig_file(file_path):
    scene_manager = csc.app.get_application().get_scene_manager()
    application_scene = scene_manager.current_scene()
    rm_on.run_raw(application_scene.domain_scene(), [0.0, 0.5, 0.0])
    rig_tool = csc.app.get_application().get_tools_manager().get_tool('RiggingToolWindowTool').editor(application_scene)
    rig_tool.open_quick_rigging_tool()
    rig_tool.load_template_by_fileName(file_path)
    rig_tool.generate_rig_elements()
    
    
def _get_object_by_id(object_list, maya_id):
    for obj in object_list:
        beh = obj.get_behaviour_by_name(common.MAYA_BEHAVIOUR_NAME)
        if beh:
            found_id = beh.datasWithSameNamesReadonly.get_by_name('maya_id')
            if found_id and found_id[0].get() == maya_id:
                print('found previous import')
                return obj
        
    return None


def _make_rig_info(scene, set_name, new_roots):
    #make a rig info and select it.
    new_selection = []
    for root in new_roots:
        new_selection.extend(hierarchy.get_object_branch_inclusive(root, root.scene))
        
    scene.edit('Change selection', lambda x: scene.select(new_selection))
    joints = scene.get_scene_objects(of_type='Joint')
    rig_info_node = None
    
    if joints:
        #Maybe we should really check to make sure the joints aren't already
        #in another rig_info node (like the official create command does)
        #but I think my logic won't get here if that's true.
        def make_mod(scene, set_name):
            nonlocal rig_info_node
            
            new_name = set_name.replace('CSC_EXPORT', '')
            new_name = set_name.rstrip('_')
            rig_info_node = scene.create_object('{}_Rig'.format(new_name))
            rig_info_beh = rig_info_node.add_behaviour('RigInfo')
            rig_info_beh.related_joints.set(joints)
        
        scene.edit('Make Rig Info', make_mod, set_name)
        
    if rig_info_node:
        scene.edit('Change selection', lambda x: scene.select([rig_info_node]))



def _get_modified_filter(existing_data, qrig_path, import_filter: fbx.FbxFilterType):
    if import_filter == fbx.FbxFilterType.ANIMATION:
        if not existing_data:
            return fbx.FbxFilterType.SKIP
        else:
            return fbx.FbxFilterType.ANIMATION
    elif import_filter == fbx.FbxFilterType.MODEL:
        if not existing_data:
            return fbx.FbxFilterType.MODEL
        else:
            return fbx.FbxFilterType.SKIP
    elif import_filter == fbx.FbxFilterType.SCENE:
        return fbx.FbxFilterType.SCENE
    elif import_filter == fbx.FbxFilterType.AUTO:
        if existing_data is None:
            #If no data exists, we'll import everything
            print("Importing scene")
            return fbx.FbxFilterType.SCENE
        elif qrig_path:
            #Else if we have data and a qrig_path exists, we'll assume
            #they just want to quick-rig the previous data
            print("Skpping FBX Data")
            return fbx.FbxFilterType.SKIP
        else:
            #else we'll assume only animation data needs updating
            print("Importing Animation")
            return fbx.FbxFilterType.ANIMATION
    else:
        raise (Exception("Add support for {}".format(import_filter)))



def _load_textures(scene):
    def mod(scene):
        temp_dir = pathlib.Path(os.path.join(tempfile.gettempdir(), 'mayacasc'))
        #load any textures
        texture_path: pathlib.Path = temp_dir.joinpath('texture_info.json')
        if texture_path.exists():
            texture_data = open(texture_path)
            texture_mapping = json.load(texture_data)
            texture_data.close()

            names = list(texture_mapping.keys())
            if not names:
                return

            objs = scene.get_scene_objects(names=names)
            for obj in objs:
                if not obj.has_behaviour('MeshObject'):
                    print("Can't find MeshObject for {}".format(obj.name))
                    continue

                if not obj.has_behaviour('TextureContainer'):
                    obj.add_behaviour('TextureContainer')
                    obj.TextureContainer.start_frame.create_data('Start frame', csc.model.DataMode.Static, 0, group_name='maya_textures')

                filenames = texture_mapping[obj.name]
                container = obj.TextureContainer
                textures = container.texture_paths.get()
                for texture in textures:
                    container.texture_paths.remove(texture)
                    
                    if hasattr(texture, 'id'):
                        container.de.delete_data(texture.id)
                    else:
                        try:
                            container.de.delete_data(texture)
                        except:
                            print("Couldn't delete {texture} when updating textures")

                #scene.su.generate_update()
                for idx, filename in enumerate(filenames):
                    data_name = f"texture {idx}"
                    container.texture_paths.create_data(data_name, csc.model.DataMode.Static, filename, group_name='maya_textures')


                obj.MeshObject.textures.set(obj.TextureContainer)
              
    scene.edit("Load Textures", mod)


def _import_maya(new_scene, import_filter: fbx.FbxFilterType):
    if new_scene:
        scene = pycsc.new_scene().ds
    else:
        scene = pycsc.get_current_scene().ds

    scene.info("Importing Maya Data")
    temp_dir = pathlib.Path(os.path.join(tempfile.gettempdir(), 'mayacasc'))
    if not temp_dir.exists():
        scene.error("Can't find Maya data")
        return


    #pre_import_roots will allow me to find everything that's new to the
    #scene once all files are imported.  scene_roots will be updated
    #after each file import has been completed.
    pre_import_roots = set(scene.get_scene_objects(only_roots=True))
    scene_roots = set(pre_import_roots)

    files = {}
    for child in temp_dir.iterdir():
        name, ext = child.name.rsplit('.', 1)
        if name not in files:
            files[name] = dict()

        files[name][ext.lower()] = str(child)
        
    #up_axis = common.get_maya_coord_system()
    #if up_axis is None:
        #print("Couldn't get Maya's Up Axis. Is Maya Running? Export Failed")
        #return

    import_rig = ''
    for key, item in files.items():
        fbx_path = ''
        qrig_path = ''
        if 'fbx' in item:
            fbx_path = item['fbx']
        if 'qrigcasc' in item:
            qrig_path = item['qrigcasc']

        if not fbx_path and not qrig_path:
            #we'll skip files that don't match the name.id format
            #the texture file is an example of one of these files
            continue

        if qrig_path:
            import_rig = qrig_path

        set_name, maya_id = key.split('.') 
        existing_data = _get_object_by_id(pre_import_roots, maya_id)
        modified_filter = _get_modified_filter(existing_data, qrig_path, import_filter)

        if modified_filter != fbx.FbxFilterType.SKIP:
            #To-Do: Find a way to make this update the mesh for existing data
            #
            #if existing_data and modified_filter == fbx.FbxFilterType.MODEL:
                ##selecting the existing data before importing a model should
                ##just update the mesh...I think.
                #root_beh = existing_data.get_behaviour_by_name(MAYA_ROOTS)
                #roots = [beh.object for beh in root_beh.behaviours.get()]

                #new_selection = []
                #for root in roots:
                    #new_selection.extend(common.hierarchy.get_object_branch_inclusive(root, root.scene.dom_scene))

                #scene.edit('Change selection', lambda x: scene.select(new_selection))


            settings = csc.fbx.FbxSettings()
            #settings.up_axis = up_axis
            fbx.import_fbx(fbx_path, modified_filter, False, settings)

            current_roots = set(scene.get_scene_objects(only_roots=True))
            new_roots = current_roots.difference(scene_roots)
            scene_roots = current_roots               


        #Let's find the stuff that was just imported and create a way
        #to search for it later.
        if existing_data is None and modified_filter != fbx.FbxFilterType.SKIP:
            scene.edit('Import maya data', common._create_data, set_name, maya_id, new_roots)
            if qrig_path:
                _make_rig_info(scene, set_name, new_roots)
        else:
            scene.info("Updated existing data")


    _load_textures(scene)


    #rig generation has to come last, so all the other automation can complete properly
    #This is outside of the main file loop, because for now we can only import one
    #rig file per import actions, so the var should be initialized, and I need  do this after all
    #the textures have been assigned.  Once I can import rigs via script (without ui interaction)
    #this can stay inside the file loop and we can move the texture loading to the end.
    if import_rig:
        print("attempting rig import")
        _import_maya_qrig_file(import_rig)


def update_models():
    _import_maya(False, fbx.FbxFilterType.MODEL)
    
    
def update_animations():
    _import_maya(False, fbx.FbxFilterType.ANIMATION)
    
    
def import_rig(new_scene):
    _import_maya(new_scene, fbx.FbxFilterType.MODEL)    
    

def import_scene(new_scene):
    _import_maya(new_scene, fbx.FbxFilterType.SCENE)
    
    
def smart_import():
    _import_maya(False, fbx.FbxFilterType.AUTO)
    
    
def update_textures():
    scene = pycsc.get_current_scene().ds
    _load_textures(scene)