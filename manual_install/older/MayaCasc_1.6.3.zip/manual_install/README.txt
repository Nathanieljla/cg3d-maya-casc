The cascadeur bridge requires pymel.  If you don't know what that means, you are likely safe to manually setup the bridge from the "Cascadeur (includes pymel)" folder.

Cascadeur (includes pymel) -> includes pymel and has the docs required for Maya 2026 and 2027

Cascadeur (excludes pymel) -> No pymel included.  Includes the install_pymel.py script.  Since there's been no official update of pymel for Maya 2026 or Maya 2027, after you install pymel you'll need to find the pymel.cache folder and duplicate the 2025 files.  Then renames the duplicates to 2026 and/or 23027.

