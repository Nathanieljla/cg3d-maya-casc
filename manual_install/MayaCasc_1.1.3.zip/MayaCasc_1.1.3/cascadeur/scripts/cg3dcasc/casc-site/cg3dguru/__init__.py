from .general import *
from . import datatypes

__author__ = "Nathaniel Albright"
__email__ = "developer@3dcg.guru"

VERSION = (0, 6, 0)
__version__ = '.'.join(map(str, VERSION))