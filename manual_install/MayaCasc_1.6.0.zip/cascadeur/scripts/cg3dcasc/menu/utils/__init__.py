

ORDER = [
    'create_proxy_rig',
    'constrain_proxy',
    'convert_textures',
    'sync_casc_id'
]