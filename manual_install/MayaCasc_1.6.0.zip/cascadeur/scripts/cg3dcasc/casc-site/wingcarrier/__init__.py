
VERSION = (1, 2, 0)

__author__ = "Nathaniel Albright"
__email__ = "developer@3dcg.guru"
__version__ = '.'.join(map(str, VERSION))