
PARAMS = {
    'label': 'Cascadeur'
}

ORDER = [
    'quick_export',
    'update',
    'send_to',
    'editor',
    'utils',
    'preferences'
]