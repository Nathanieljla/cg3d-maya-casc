
PARAMS = {
    'label': 'Update Model(s)'
}


def command(*args, **kwargs):
    import cg3dcasc
    cg3dcasc.update_models()